import{test} from "../fixtures/salesForceFixtures"


test("Verify lead using fixture",async({SFlogin,SFapi})=>{
    //api
    const leadId = await SFapi.createResource()
    const CompanyName = await SFapi.fetchUser(leadId)

    //UI
    await SFlogin.enterUsername("krishmlky74.7a2672abb1ba@agentforce.com")
    await SFlogin.verifyUsername()
    await SFlogin.enterPassword("Password@1234")
    const SFhome = await SFlogin.clickLogin()
    const SFlead = await SFhome.navigateToLeadPage("Leads")
    await SFlead.searchLead(CompanyName)
})