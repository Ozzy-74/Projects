import{test} from "@playwright/test"
import { LoginPage } from "../pages/login"

test("Learn to verify lead using the reusable function",async({page})=>{

    await page.goto("https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com")

    const LP = new LoginPage(page)

    await LP.enterUsername("krishmlky74.7a2672abb1ba@agentforce.com")
    await LP.verifyUsername()

    await LP.enterPassword("Password@1234")
    const HP = await LP.clickLogin()
    const LeadPage=await HP.navigateToLeadPage("Leads")
    
    await LeadPage.searchLead("Kendrick Lamar")
})  