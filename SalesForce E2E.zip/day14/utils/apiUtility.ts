import { APIRequestContext } from "@playwright/test";

export class SalesForceAPI {
    private sf_token!:string;
    private userId!:string;


    constructor(private request: APIRequestContext) { }

    async generateToken() {
        const response = await this.request.post("https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/oauth2/token", {
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded"
            },
            form: {
                "grant_type": "client_credentials",
                "client_id": "3MVG9JJwBBbcN47JK.1mDGLiEi_FHEmdJjL310B_QWoR_nrbY73bZO6q7USKSEg8J6cF1gep83ri2RzUuVqGi",
                "client_secret": "43864DB8E9F48AEF7AD25723DB968007EDFFBF91CE54318BF8E9E49EF4290864",
            }
        });
        let responseBody = await response.json()
        this.sf_token = responseBody.access_token //Oauth key
        console.log(this.sf_token, response.status())

    }

    async createResource(){
         const response = await this.request.post("https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/data/v67.0/sobjects/Lead", {
                    headers: {
                        "Authorization": `Bearer ${this.sf_token}`,
                        "Accept": "application/json",
                        "Content-Type": "application/json"
                    },
                    data: {
                        "Salutation": "Mr.",
                         "FirstName":"Kanye ",	
                         "LastName":"west",
                         "Company":"ye inc"
                    }
        
                })
        
                let responseBody = await response.json()
                this.userId = responseBody.id
                console.log(this.userId, response.json())
                console.log(response.text())

                return responseBody.id
    }

    async fetchUser(userId:string){
            const response = await this.request.get(`https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/data/v67.0/sobjects/Lead/${userId}`, {
                    headers: {
                        "Authorization": `Bearer ${this.sf_token}`,
                        "Accept": "application/json",
                        "Content-Type": "application/json"
                    }
        
                })
        
                let responseBody = await response.json()
                console.log(response.json())
                console.log("Fetched incident", responseBody.Company)
                return responseBody.Company  
    }
}