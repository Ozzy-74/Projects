import{expect, test}from "@playwright/test"
import { request } from "node:http";

test.describe.serial("Salesforce api",async()=>{
    let sforce_token:any;
    let userId:any;

    test("generate oauth token",async({request})=>{
        let response = await request.post("https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/oauth2/token",{
            headers:{
                "Accept": "Application.json",
                "Content-Type": "application/x-www-form-urlencoded"
            },
            form:{
                "client_id":"3MVG9JJwBBbcN47JK.1mDGLiEi_FHEmdJjL310B_QWoR_nrbY73bZO6q7USKSEg8J6cF1gep83ri2RzUuVqGi",
                "client_secret":"43864DB8E9F48AEF7AD25723DB968007EDFFBF91CE54318BF8E9E49EF4290864",
                "grant_type":"client_credentials"
            }
        })

        let responseBody = await response.json()
        sforce_token = responseBody.access_token
        expect(response.status()).toBe(200)
        console.log("Token:"+ sforce_token, response.status())
    })

    test("Create new lead", async({request}) =>{
        let response = await request.post("https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/data/v67.0/sobjects/Lead",{
            headers:{
                "Authorization": `Bearer ${sforce_token}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            data:{
                "Salutation": "Mr.",
                "FirstName":"Travis",	
                "LastName":"Scott",
                "Company":"CACTUS JACK"
            }
        })

        let responseBody = await response.json();
        userId = responseBody.id
        expect(response.status()).toBe(201)
        console.log("Lead created:"+ userId,response.json())
    })

     test("Fetch new lead", async({request}) =>{
        let response = await request.get(`https://orgfarm-141cbd5f93-dev-ed.develop.my.salesforce.com/services/data/v67.0/sobjects/Lead/${userId}`,{
            headers:{
                "Authorization": `Bearer ${sforce_token}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
        })

        let responseBody = await response.json();
        expect(response.status()).toBe(200)
        console.log("Fetched data:"+userId,response.status())
        console.log(responseBody.result)
     })    

})